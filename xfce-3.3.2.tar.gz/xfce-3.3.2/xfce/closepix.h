/* XPM */
static char *closepix[] =
{
  "8 4 3 1",
  ". c none",
  "X c #303030",
  "o c #ffffff",
  "XXXXXXXo",
  "X......o",
  "X......o",
  "Xooooooo"};
