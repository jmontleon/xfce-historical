/*
   XPM 
 */
static char *minbutdn[] =
{
/**/
"14 7 4 1",
/**/
  " 	s mask	c none",
  "X      c #ffffff",
  "o      c #303030",
  ".      c yellow",
  "oooooooooooooo",
  " oo........XX ",
  "  oo......XX  ",
  "   oo....XX   ",
  "    oo..XX    ",
  "     ooXX     ",
  "      oX      "};
