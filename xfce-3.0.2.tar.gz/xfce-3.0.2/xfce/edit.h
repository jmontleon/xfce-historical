/* XPM */
static char *edit[] =
{
/*
   width height num_colors chars_per_pixel 
 */
  "    48    48        8            1",
/*
   colors 
 */
  "+ m mask c none",
  "# c #595959",
  "a c #ffffff",
  "b c #dfdfdf",
  "c c #595959",
  "d c #a2a2a2",
  "e c #00ff00",
  "f c #ff00ff",
/*
   pixels 
 */
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++###############################a++++++++",
  "++++++++#aaaaaaaaaaaaaaaaaaaaaaaaaaaaa#a++++++++",
  "++++++++#abbbbbbbbbbbbbbbbbbbbbbbbbbbb#a++++++++",
  "++++++++#abbbbbbbbbbbbbbbbbbbbbbbbbbbb#a++++++++",
  "++++++++#abbbccdccdcbdccbdcdccddbbbbbb#a++++++++",
  "++++++++#abbdcbbdcbddbdcdbbdcbcbbbbbbb#a++++++++",
  "++++++++#abbbbbbbbbbbbbbbbbbbbbbbbbbbb#a++++++++",
  "++++++++#abbbbbbbbbbbbbbbbbbbbbbbbbbbb#a++++++++",
  "++++++++#abbcdddcbccbcdcbbccbcddccbbbb#a++++++++",
  "++++++++#abbddcbbbcddbcbddbbddddbbbbbb#a++++++++",
  "++++++++#abbbbbbbbbbbbbbbbbbbbbbbbbbbb#a++++++++",
  "++++++++#abbbbbbbbbbbbbbbbbbbbbbbbbbbb#a++++++++",
  "++++++++#abbdcbddcbbccbcdbbcddcbccccbb#a++++++++",
  "++++++++#abbddbbdddbbdddbbbdddbbbdddbb#a++++++++",
  "++++++++#abbbbbbbbbbbbbbadddbbbbbbbbbb#a++++++++",
  "++++++++#abbbbbbbbbbbbbba###ddbbbbbbbb#a++++++++",
  "++++++++#abbdcbcddcbcdcba###ccdbbbbbbb#a++++++++",
  "++++++++#abbddbbddbbbddba####ccdbbbbbb#a++++++++",
  "++++++++#abbbbbbbbbbbbbbba#eeccdbbbbbb#a++++++++",
  "++++++++#abbbbbbbbbbbbbbbaeeeeccdbbbbb#a++++++++",
  "++++++++#abbbbbbbbbbbbbbbbaeeeccdbbbbb#a++++++++",
  "++++++++#abbbbbbbbbbbbbbbbaeeeeccdbbbb#a++++++++",
  "++++++++#abbbbbbbbbbbbbbbbbaeeeccdbbbb#a++++++++",
  "++++++++#abbbbbbbbbbbbbbbbbaeeeeccdbbb#a++++++++",
  "++++++++#abbbbbbbbbbbbbbbbbbaeeeccdbbb#a++++++++",
  "++++++++#abbbbbbbbbbbbbbbbbbaeeeeccdbb#a++++++++",
  "++++++++#abbbbbbbbbbbbbbbbbbbaeeeccdbb#a++++++++",
  "++++++++#abbbbbbbbbbbbbbbbbbbaeeeeccdb#a++++++++",
  "++++++++#abbbbbbbbbbbbbbbbbbbbaeeeccdb#a++++++++",
  "++++++++#abbbbbbbbbbbbbbbbbbbbaeeeeccd#a++++++++",
  "++++++++#abbbbbbbbbbbbbbbbbbbbbaeeeccd#a++++++++",
  "++++++++#abbbbbbbbbbbbbbbbbbbbbaeeeecc#a++++++++",
  "++++++++#abbbbbbbbbbbbbbbbbbbbbbaeeecc#a++++++++",
  "++++++++#abbbbbbbbbbbbbbbbbbbbbbaeeeeccd++++++++",
  "++++++++#abbbbbbbbbbbbbbbbbbbbbbbaeeeccd++++++++",
  "++++++++#########################aeececcd+++++++",
  "++++++++aaaaaaaaaaaaaaaaaaaaaaaaaaaceeccd+++++++",
  "++++++++++++++++++++++++++++++++++aeeffccd++++++",
  "+++++++++++++++++++++++++++++++++++afffccd++++++",
  "+++++++++++++++++++++++++++++++++++affff#cd+++++",
  "++++++++++++++++++++++++++++++++++++afff#cd+++++",
  "++++++++++++++++++++++++++++++++++++aff##cd+++++",
  "++++++++++++++++++++++++++++++++++++++##cdd+++++",
  "+++++++++++++++++++++++++++++++++++++++ddd++++++"};
