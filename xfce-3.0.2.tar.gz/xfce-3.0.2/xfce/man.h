/* XPM */
static char *man[] =
{
/*
   width height num_colors chars_per_pixel 
 */
  "    48    48        7            1",
/*
   colors 
 */
  "+ m mask c none",
  ". c #bebebe",
  "# c #595959",
  "a c #183c59",
  "b c #a2a2a2",
  "c c #797979",
  "d c #ffffff",
/*
   pixels 
 */
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++##########++++++++++++++++++++",
  "++++++++++########abcccccc#a++++++++++++++++++++",
  "++++++++++#cd.bbcaabcccccc#a++++++++++++++++++++",
  "++++++++++#cd.bbcaabcccccc#a+++++##########+++++",
  "++++++++++##d.bbcaabcccccc#a+++++#dd..bbbca+++++",
  "++++######a#d.bbcaabcccccc#a#####add..bbbcab++++",
  "++++#dddbba#d.bbcaabcccccc#aabc#aadd..bbbca#b+++",
  "++++#d.bbca#dbc#caabcccccc#aabc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaabcccccc#aabc#aaddbbcc#ca#b+++",
  "++++#dbc#ca#dbc#caabddddddaaabc#aaddbbcc#ca#b+++",
  "++++#dbc#cacd.bbcaaddddddddaabc#aadd..bbbca#b+++",
  "++++#d.bbcacdbc#caddddddddddabc#aaddbbcc#ca#b+++",
  "++++#dbc#cacd.bbcddddaaa#ddddbc#aadd..bbbca#b+++",
  "++++#dbc#ca#d.bbcdddaaccc#dddbc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcdddacccc#dddbc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcdddacccc#dddbc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaaacccc#ddddbc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaabccc#ddddabc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaabcc#ddddaabc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaabc#ddddaaabc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaab#dddda#aabc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaab#dddac#aabc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaab#dddac#aabc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaabcaaaac#aabc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaabcccccc#aabc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaab#dddcc#aabc#aadd..bbbca#b+++",
  "++++#d.bbca#dbc#caab#dddac#aabc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaab#dddac#aabc#aadd..bbbca#b+++",
  "++++#dbc#ca#dbc#caabcaaaac#aabc#aadd..bbbca#b+++",
  "++++#dbc#ca#d.bbcaabcccccc#aabc#aadd..bbbca#b+++",
  "++++#d.bbca#dbc#caabcccccc#aabc#aaddbbcc#ca#b+++",
  "++++#d.bbca#d.bbcaabcccccc#aabc#aaddbbcc#ca#b+++",
  "++++#d.bbca#d.bbcaabcccccc#aabc#aadd..bbbca#b+++",
  "++++#d.bbca#d.bbcaabcccccc#aabc#aadd..bbbca#b+++",
  "++++#bbbcca#d.bbcaabcccccc#aabc#aa########a#b+++",
  "++++#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#aaaaaa#b+++",
  "++++#dddddddddddddddddddddddddddddddb#######b+++",
  "+++++++++++++++++++++++++++++++++++++bbbbbbbb+++",
  "++++++++++++++++++++++++++++++++++++++bbbbbbb+++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++"};
