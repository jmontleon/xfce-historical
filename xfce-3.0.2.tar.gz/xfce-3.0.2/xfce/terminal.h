/* XPM */
static char *term[] =
{
/*
   width height num_colors chars_per_pixel 
 */
  "    48    48        8            1",
/*
   colors 
 */
  "+ m mask c none",
  ". c #bebebe",
  "# c #615959",
  "a c #ffffff",
  "c c #a2a2a2",
  "d c #183c59",
  "e c #797979",
  "f c #183c59",
  
/*
   pixels 
 */
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "+++++++++++########################+++++++++++++",
  "+++++++++###aaaaaaaaaaaaaaaaaaaaaac###++++++++++",
  "+++++++##acacacacacacaccacacacacacacac##++++++++",
  "++++++#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.#a+++++++",
  "++++++#a...............................#a+++++++",
  "++++++#a...............................#a+++++++",
  "++++++#a.############################a.#a+++++++",
  "++++++#a.#fffffffffffffffffffffffffffa.#a+++++++",
  "++++++#a.#fffffffffffffffffffffffffffa.#a+++++++",
  "++++++#a.#ffffcacfcacfaaccfcacfffffffa.#a+++++++",
  "++++++#a.#fffffffffffffffffffffffffffa.#a+++++++",
  "++++++#a.#ffffaaafaccafccaafccaffffffa.#a+++++++",
  "++++++#a.#fffffffffffffffffffffffffffa.#a+++++++",
  "++++++#a.#ffffaccfacfccfacfaaccffffffa.#a+++++++",
  "++++++#a.#fffffffffffffffffffffffffffa.#a+++++++",
  "++++++#a.#ffffcafaafcacfaccfacfffffffa.#a+++++++",
  "++++++#a.#fffffffffffffffffffffffffffa.#a+++++++",
  "++++++#a.#ffffcafacffffffffffffffffffa.#a+++++++",
  "++++++#a.#fffffffffffffffffffffffffffa.#a+++++++",
  "++++++#a.#fffffffffffffffffffffffffffa.#a+++++++",
  "++++++#a.#fffffffffffffffffffffffffffa.#a+++++++",
  "++++++#a.#fffffffffffffffffffffffffffa.#a+++++++",
  "++++++#a.#fffffffffffffffffffffffffffa.#a+++++++",
  "++++++#a.#aaaaaaaaaaaaaaaaaaaaaaaaaaaa.#a+++++++",
  "++++++#a...............................#a+++++++",
  "++++++#a...............................#a+++++++",
  "++++++#################################da+++++++",
  "++++++aaaaaaa#######cccccccc######aaaaaaa+++++++",
  "++++++++###########eeeeeeeeee#########a+++++++++",
  "+++++++#aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#a++++++++",
  "++++++#aaaa#a#a#a#a#a#aa#a#aaaa#a#a#aa.#a+++++++",
  "+++++#aaa#c#c#c#c#c#c#cc#c#c#caaa#c#c#a.#a++++++",
  "++++#aaaac#c#c#c#c#c#c##c#c#c#caaa#c#caa.#a+++++",
  "+++#aaaa##c#cccccccccccccccc#c#aaaa#c##aa.#a++++",
  "+++daaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa#a+++",
  "+++dccccccccccccccccccccccccccccccccccccccc#a+++",
  "+++#########################################a+++",
  "+++aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa+++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++",
  "++++++++++++++++++++++++++++++++++++++++++++++++"};
