

/*
   XPM 
 */
static char *minilock[] =
{
/*
   width height num_colors chars_per_pixel 
 */
  "    16    18        7            1",
/*
   colors 
 */
  "+ m mask c none",
  "# c #183c59",
  "a c #bebebe",
  "b c #fff7f7",
  "c c #797979",
  "d c #595959",
  "e c #a2a2a2",
/*
   pixels 
 */
  "+++++######+++++",
  "++++#aaaaaab++++",
  "+++#accccccdb+++",
  "++#acdddddecdb++",
  "++#acdbbbbacdb++",
  "++#acdb++#acdb++",
  "++#acdb++#acdb++",
  "###ecd####acdbbb",
  "#aaaaaaaaaaaaaab",
  "#aeeeeeeeeeeeedb",
  "#aeeaaaaaaaaeedb",
  "#aeecccccccceedb",
  "#aeeeeeeeeeeeedb",
  "#aeeaaaaaaaaeedb",
  "#aeecccccccceedb",
  "#aeeeeeeeeeeeedb",
  "#ddddddddddddddb",
  "bbbbbbbbbbbbbbbb"};
