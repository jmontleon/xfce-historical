/*
   XPM 
 */
static char *minipnt[] =
{
/*
   width height num_colors chars_per_pixel 
 */
  "    24    18        9            1",
/*
   colors 
 */
  "+ m mask c none",
  ". c #bebebe",
  "# c #183c59",
  "a c #ffffff",
  "b c #ff00ff",
  "c c #ff6145",
  "d c #ffff00",
  "e c #0000ff",
  "f c #00ff00",
/*
   pixels 
 */
  "++++++++########++++++++",
  "++++++##aaaaaaaa##++++++",
  "++++##aaa.......aa##++++",
  "+++#aaa...........aa#+++",
  "++#aa..bbbb...cccc..a#++",
  "+#aa..bbbbbb.cccccc..#++",
  "+#a....bbbb...cccc..#a++",
  "#aa................#a+++",
  "#a..dddd..........#a###+",
  "#a.dddddd.........aaaa#a",
  "#a..dddd..............#a",
  "+a#............eeee..#a+",
  "+a#......ffff.eeeeee.#a+",
  "++a#....ffffff.eee..#a++",
  "+++a##...ffff.....##a+++",
  "++++aa###......###aa++++",
  "++++++aa########aa++++++",
  "++++++++aaaaaaaa++++++++"};
