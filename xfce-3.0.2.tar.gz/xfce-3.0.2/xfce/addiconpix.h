/*
   XPM 
 */
static char *addiconpix[] =
{
/**/
"20 20 3 1",
/**/
  " 	s mask	c none",
  "X      c #ffffff",
  "o      c #303030",
  "oooooooooooooooooooX",
  "o                  X",
  "o                  X",
  "o   oooooooooooo   X",
  "o   o          X   X",
  "o   o          X   X",
  "o   o          X   X",
  "o   o          X   X",
  "o   o          X   X",
  "o   o          X   X",
  "o   o          X   X",
  "o   o          X   X",
  "o   o          X   X",
  "o   o          X   X",
  "o   o          X   X",
  "o   o          X   X",
  "o   XXXXXXXXXXXX   X",
  "o                  X",
  "o                  X",
  "oXXXXXXXXXXXXXXXXXXX"};
